function[square]=cal_square(int)
square=int*int;
end


