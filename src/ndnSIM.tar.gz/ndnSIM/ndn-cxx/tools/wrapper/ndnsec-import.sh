#!@SH@

`dirname "$0"`/ndnsec import "$@"