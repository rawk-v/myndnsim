#!@SH@

`dirname "$0"`/ndnsec cert-install "$@"