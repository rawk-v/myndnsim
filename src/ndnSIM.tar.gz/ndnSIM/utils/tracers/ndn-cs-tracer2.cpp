#include "ndn-cs-tracer2.hpp"

#include "ns3/node.h"
#include "ns3/packet.h"
#include "ns3/config.h"
#include "ns3/names.h"
#include "ns3/callback.h"
#include "apps/ndn-app.hpp"
#include "ns3/node-list.h"
#include "model/cs/ndn-content-store.hpp"
#include "ns3/simulator.h"
#include "ns3/log.h"
#include <boost/lexical_cast.hpp>
#include <utility>
#include <tuple>
#include <fstream>
#include <map>
#include <functional>
NS_LOG_COMPONENT_DEFINE("ndn.CsTracer2");
  typedef std::pair<uint32_t,uint32_t> HitMiss;
  typedef std::map<uint64_t,HitMiss> Category;
  typedef std::map<std::string,Category> SpecTrace;

namespace ns3
{
namespace ndn
{ using namespace std;
  using namespace boost;




namespace cs
{
static std::list<std::tuple<shared_ptr<std::ostream>,std::list<Ptr<CsTracer2>>>> g_tracers;

void CsTracer2::InstallAll(const Time time)
{
   std::list<Ptr<CsTracer2>> tracers;
   for(NodeList::Iterator ite=NodeList::Begin();ite!=NodeList::End();ite++)
   {
	   Install(*ite,time);
   }

}

void CsTracer2::Install(const NodeContainer &nodes,Time time)
 {

	for(NodeContainer::Iterator ite=nodes.Begin();ite!=nodes.End();ite++)
	{
		Install(*ite,time);
	}



 }
void CsTracer2::Install(Ptr<Node> node,Time time)
{
 std::list<Ptr<CsTracer2>> tracers;
 shared_ptr<std::ofstream> outputStream;
 std::string filename("node "+boost::lexical_cast<std::string>(node->GetId())+" cs.txt");
 shared_ptr<std::ofstream> os(new std::ofstream);
 //os->open(filename.c_str(),std::ios_base::out|std::ios_base::trunc);
 //if(!os->is_open())
 //{
//	 NS_LOG_ERROR("file "<<filename<< "cannot be opened");
//	 return ;
// }
// else
 //{
	outputStream=os;
// }
 Ptr<CsTracer2> trace=InstallImpl(node,time);
 tracers.push_back(trace);

 g_tracers.push_back(std::make_tuple(os,tracers));
}





Ptr<CsTracer2> CsTracer2::InstallImpl(Ptr<Node> node,Time time)
{
	Ptr<CsTracer2> trace=Create<CsTracer2>(node,time);
  trace->SetPrintTime(time);
  return trace;
}




CsTracer2::CsTracer2(Ptr<Node> node,Time time):m_nodePtr(node),printTime(time)
{
	m_node=boost::lexical_cast<std::string>(m_nodePtr->GetId());
	Connect();
	std::string name=Names::FindName(node);
	if(!name.empty())
	{
		m_node=name;
	}
}

CsTracer2::~CsTracer2()
{

}

void CsTracer2::Connect()
{
	Ptr<ContentStore> cs=m_nodePtr->GetObject<ContentStore>();
	  cs->TraceConnectWithoutContext("CacheHits", MakeCallback(&CsTracer2::CacheHits, this));   //name	The name of the target trace source
	  cs->TraceConnectWithoutContext("CacheMisses", MakeCallback(&CsTracer2::CacheMisses, this));
}

void CsTracer2::SetPrintTime(Time time)
{
	m_printEvent.Cancel();
	m_printEvent=Simulator::Schedule(time,&CsTracer2::PrintHitMiss,this);
}

bool  CsTracer2::PrintHitMiss()
{
	std::ofstream os;

	std::string filename("NODE  "+boost::lexical_cast<std::string>(m_nodePtr->GetId())+" .txt");

		os.open(filename.c_str(),std::ios_base::out|std::ios_base::trunc);
		if(!os.is_open())
		{
			std::cout<<"IN  "<<__FUNCTION__<<"  FILE "<<filename<<" CANNOT OPEN"<<std::endl;
			return false;
		}
		else
		{
			using namespace std;
			os<<"RECORED IN CONTENT STORE"<<endl;
			SpecTrace::const_iterator iteforspec;
			for(iteforspec=m_spectrace.begin();iteforspec!=m_spectrace.end();iteforspec++)
			{
				 os<<"FROM NODE  "<<m_nodePtr->GetId()<<endl;

				// os<<policy::GetName().c_str()<<endl;
	                        os<<"prefix----------------------------------------------------"<<iteforspec->first<<endl<<"Cat\t"<<"Hit\t"<<"Miss\t"<<"All\t"<<"HitRatio"<<endl;
				Category::const_iterator iteforcat;
				double hit_ratio=0;
				for(iteforcat=iteforspec->second.begin();iteforcat!=iteforspec->second.end();iteforcat++)
				{   hit_ratio=(double)(iteforcat->second.first)/((double)(iteforcat->second.second)+(double)(iteforcat->second.first));
					os<<iteforcat->first<<"\t"<<iteforcat->second.first<<"\t"<<iteforcat->second.second<<"\t"<<iteforcat->second.second+iteforcat->second.first<<"\t"<<hit_ratio<<endl;
				}


			}
	       return true;
		}
}
void CsTracer2::CacheHits(shared_ptr<const Interest> interest,shared_ptr<const Data>data)
{
	SaveHitMissInfo(interest,true);

}
void CsTracer2::CacheMisses(shared_ptr<const Interest > interest)
{
	SaveHitMissInfo(interest,false);
}

bool CsTracer2::SaveHitMissInfo(shared_ptr<const Interest> interest,bool flag)
{
	ns3::ndn::Name m_interestname=interest->getName();
		std::string prefix=m_interestname.at(0).toUri();
		auto Sub=m_interestname.at(-1);
		auto Pri=m_interestname.at(-2);

		if(prefix=="localhost") //　this is not a interest for data
			{  //std::cout<<"this is localhost"<<std::endl;
			      return false;
			}
		else //this is a valid interest
		{   uint64_t priseq;
			if(Pri.isSequenceNumber()) // with sub
			 priseq=Pri.toSequenceNumber();
		    else priseq=Sub.toSequenceNumber();// without sub

			SpecTrace::iterator specite=m_spectrace.find(prefix);
			if(specite==m_spectrace.end()) //  no record for the prefix
			{   //std::cout<<"FOUND NO PREFIX"<<std::endl;


				HitMiss hitmiss_tmp;
				if(flag)  hitmiss_tmp=HitMiss(1,0); //hit!
				else
				{
					hitmiss_tmp=HitMiss(0,1); //std::cout<<interest->getName().toUri()<<std::endl;
				}
					 //miss!
				Category cat_tmp;
				cat_tmp.insert(std::make_pair(priseq,hitmiss_tmp));
				m_spectrace.insert(std::make_pair(prefix,cat_tmp));
				return true;
			}

			else//找到了该前缀
			{     //std::cout<<"FOUND THE PREFIX"<<std::endl;
				Category &cat_tmp=specite->second;
				Category::iterator iteforcat=cat_tmp.find(priseq);
				if(iteforcat==cat_tmp.end())// not entry
				{    //std::cout<<"FOUND THE PREFIX BUT NOT FOUND PRI"<<std::endl;
					HitMiss hitmiss_tmp;
					if(flag)   hitmiss_tmp=HitMiss(1,0);
					else
					{
						hitmiss_tmp=HitMiss(0,1);
						//std::cout<<interest->getName().toUri()<<std::endl;

					}

	                  cat_tmp.insert(std::make_pair(priseq,hitmiss_tmp));
						return true;
				}


				else //　find the category
				{
					if(flag) {iteforcat->second.first++; return true;}
					else {iteforcat->second.second++;  return true;}
				}
			}

		}


}
}





 //static std::list<std::tuple<shared_ptr<std::ostream>, std::list<Ptr<CsTracer>>>> g_tracers;














}
}
