#ifndef SEQDEALING_HPP
#define SEQDEALING_HPP

#include <boost/lexical_cast.hpp>
#include <map>
#include "ns3/ndnSIM-module.h"
#include "ns3/core-module.h"





typedef std::map<uint64_t,uint64_t> InterestInfo;






struct SeqDealing
{
	static void encode(const uint32_t &Pri,const uint32_t &Sub,uint32_t &EncodedSeq)
	{    
		std::string seqstr=boost::lexical_cast<std::string>(Pri+10000)+boost::lexical_cast<std::string>(Sub);
		EncodedSeq=boost::lexical_cast<uint32_t>(seqstr);
	}

	static void decode(const uint32_t & EncodedSeq,uint32_t &Pri,uint32_t &Sub )
	{
		std:: string seqstr=boost::lexical_cast<std::string>(EncodedSeq);
			   std::string PriStr=seqstr.substr(0,5);
			   	Pri=(boost::lexical_cast<uint32_t>(PriStr))-10000;
			   	std::string SubStr=seqstr.substr(5);
			   	Sub=boost::lexical_cast<uint32_t>(SubStr);
	}

	static bool Sub(const uint32_t &EncodedSeq)
	{
		return EncodedSeq>10000;
	}

	static bool ToFind( std::map<uint32_t,uint32_t> &SeqContainer,const uint32_t &seq)
		{
		   std::map<uint32_t,uint32_t>::iterator ite;
		  ite=SeqContainer.find(seq);
		  if(ite==SeqContainer.end()){ std::cout<<"not find"<<std::endl; return false;   }
		  else { std::cout<<"find   "<<seq<<"  "; return true;}
		}

	static bool InterestCount(const shared_ptr<ns3::ndn::Interest> &m_interest,InterestInfo &m_interestinfo)
	{  //std::cout<<"INTO INTEREST COUNT"<<std::endl;
		ns3::ndn::Name m_name=m_interest->getName();
		auto Sub=m_name.at(-1);
		auto Pri=m_name.at(-2);
		if(Pri.isSequenceNumber())
		{  //std::cout<<"WITH SUB"<<std::endl;
			m_interestinfo[Pri.toSequenceNumber()]++;

			return true;
		}


		else
		{
			Pri=Sub;
			if(Pri.isSequenceNumber())
			{   //std::cout<<" WITHOUT SUB"<<std::endl;
				m_interestinfo[Pri.toSequenceNumber()]++;
				return true;
			}
			else return false;
		}


	}

	static bool ShowInterestInfo(const InterestInfo &m_interestinfo,const std::string &file_name)
	{
		using namespace boost;
		//boost::shared_ptr<std::ofstream> os=new std::ofstream();

       double sum=0;
       double ratio=0;
		std::ofstream os;
		os.open(file_name.c_str(),std::ios_base::out|std::ios_base::trunc);

		if(os.is_open())
		{
			InterestInfo::const_iterator ite;



			for(ite=m_interestinfo.begin();ite!=m_interestinfo.end();ite++)
			{
				sum=sum+ite->second;
			}

            os<<"Number of all interest = "<<sum<<std::endl;

			os<<"Category"<<"\t"<<"Count"<<"\t"<<"Ratio"<<std::endl;

			for(ite=m_interestinfo.begin();ite!=m_interestinfo.end();ite++)
			{   ratio=ite->second/sum;
				os<<ite->first<<"\t"<<ite->second<<"\t"<<ratio<<std::endl;

			}


                 return true;



		}
		else
		{
			//NS_LOG_ERROR("FILE CANNNOT OPEN!");
			std::cout<<"FILE CANNOT OPEN"<<std::endl;
			return false;
		}




	}



};


#endif
