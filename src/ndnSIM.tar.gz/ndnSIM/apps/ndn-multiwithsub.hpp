#ifndef NDN_MULTI_WITH_SUB_H_
#define NDN_MULTI_WITH_SUB_H_

#include "ns3/ndnSIM/model/ndn-common.hpp"
#include "ndn-consumer.hpp"
#include "ndn-consumer-cbr.hpp"
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/uinteger.h"
#include "ns3/double.h"
#include "ns3/random-variable-stream.h"
#include <boost/lexical_cast.hpp>
#include <map>
#include <string>
#include "utils/SeqDealing.hpp"



typedef std::map<uint64_t,uint64_t> InterestInfo;









namespace ns3
{
  namespace ndn
  {
   class MultiWithSub:public ConsumerCbr
   {
   public :static TypeId GetTypeId();
           MultiWithSub();
           virtual ~MultiWithSub();
           virtual void SendPacket();
           uint32_t GetNextPriSeq();
           uint32_t GetNextSubSeq();
           void test();
          // virtual void StartApplication();

           virtual void PrintInfo(void);

   protected:
           virtual void ScheduleNextPacket();
   private:
           void SetNumberOfPriContents(uint32_t NumOfPriContents) ;
           uint32_t GetNumberOfPriContents() const;
           void SetNumberOfSubContents(uint32_t NumOfSubContents);
           uint32_t GetNumberOfSubContents() const;
           void SetQ(double q);
           double GetQ() const;
           void SetS(double s);
           double GetS() const;
           void SetPriRngSeed(uint32_t seed);
           uint32_t GetPriRngSeed() const;
           void SetSubRngSeed(uint32_t seed);
           uint32_t GetSubRngSeed() const;
   private:
           uint32_t m_Pri;
           uint32_t m_Sub;
           uint32_t m_PriRngSeed;
           uint32_t m_SubRngSeed;
           double m_q;
           double m_s;
           std::vector<double>m_Pri_Cdf;
           std::vector<double>m_Sub_Cdf;
           Ptr<UniformRandomVariable>m_PriSeqRng;
           Ptr<UniformRandomVariable>m_SubSeqRng;

           InterestInfo m_interestinfo;


   };




  }
}

#endif
